# Adaptive Phishing (prototype)

A single-page phishing URL scanner prototype with feedback-based learning.
Everything runs in the browser. Demo data only; accounts and scan history are stored in the visitor's own browser, not on a server.

## Host it on GitHub Pages
1. Create a new GitHub repository (for example `adaptive-phishing`).
2. Upload `index.html`, `.nojekyll` and `README.md` to the repository root.
3. Go to Settings > Pages, set Source to "Deploy from a branch", choose `main` and `/ (root)`, then Save.
4. After a minute your site is live at `https://<your-username>.github.io/<repo-name>/`.
